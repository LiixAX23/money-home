<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Realizado!</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <h1>🎉 Sucesso!</h1>
        <p class="success-text">✅ Seu cadastro foi concluído! Agora, faça login e comece a faturar. 💰</p>
        <a href="login.html" class="btn-voltar">🔑 Ir para o Login</a>
    </div>
</body>
</html>

