<?php
// Informações do banco de dados
$host = "localhost";           // No seu caso, como está usando local, é localhost
$dbname = "inztagro_com";      // Nome do seu banco de dados
$user = "root";                // Usuário padrão do MariaDB no local
$password = "";                // Senha do banco (em branco se não definiu)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Conexão bem-sucedida!"; // Pode comentar ou remover
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}
?>
